const express = require("express");
const bodyParser = require("body-parser");
const helmet = require("helmet");
const morgan = require("morgan");
const cors = require("cors");
const session = require("express-session");
const { limiter } = require("./middleware/rateLimiter");
const RedisStore = require("connect-redis");
const redisClient = require("./config/redis");
const dbConnect = require("./config/db");
const { errorHandler } = require("./middleware/errorHandler");
require("dotenv").config();

const app = express();

// Middlewares
app.use(helmet());
app.use(morgan("dev"));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(limiter);

app.use(
  session({
    store: new RedisStore({ client: redisClient }),
    secret: process.env.SESSION_SECRET || "secret",
    resave: false,
    saveUninitialized: false,
  })
);

// Database connection
dbConnect();

// Routes
app.use("/admin", require("./routes/admin"));
app.use("/user", require("./routes/user"));
app.use("/payment", require("./routes/payment"));

// Error handling middleware
app.use(errorHandler);

module.exports = app;