const mongoose = require("mongoose");

const ebookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  price: { type: Number, required: true },
  description: { type: String },
  fileUrl: { type: String, required: true },
  posterUrl: { type: String },
  author: { type: String, default: "Anonymous" },
  category: { type: String },
  isVisible: { type: Boolean, default: true },
});

module.exports = mongoose.model("Ebook", ebookSchema);