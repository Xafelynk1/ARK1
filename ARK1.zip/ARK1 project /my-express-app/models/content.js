const mongoose = require("mongoose");

const contentSchema = new mongoose.Schema({
  title: { type: String, required: true },
  type: { type: String, enum: ["ebook", "audio", "video", "blog"], required: true },
  file: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Content", contentSchema);