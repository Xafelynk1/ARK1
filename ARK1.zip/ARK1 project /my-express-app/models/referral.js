const mongoose = require("mongoose");

const referralSchema = new mongoose.Schema({
  referredBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  reward: { type: Number, default: 0 },
  referredOn: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Referral", referralSchema);