const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: "user" },
  specialRules: [{ type: String }],
  referralCount: { type: Number, default: 0 },
  referralCode: { type: String, default: "" },
  purchases: [{ type: mongoose.Schema.Types.ObjectId, ref: "Ebook" }],
  quizzes: [{ type: mongoose.Schema.Types.ObjectId, ref: "Quiz" }],
  points: { type: Number, default: 0 },
  totalEarned: { type: Number, default: 0 },
});

module.exports = mongoose.model("User", userSchema);
