const Quiz = require("../models/Quiz");

const createQuiz = async (req, res, next) => {
  try {
    const { question, options, correctOption, timer } = req.body;
    const quiz = await Quiz.create({ question, options, correctOption, timer });
    res.status(201).json({ message: "Quiz created successfully", quiz });
  } catch (error) {
    next(error);
  }
};

const updateQuiz = async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const quiz = await Quiz.findByIdAndUpdate(id, updates, { new: true });
    res.status(200).json({ message: "Quiz updated successfully", quiz });
  } catch (error) {
    next(error);
  }
};

const deleteQuiz = async (req, res, next) => {
  try {
    const { id } = req.params;
    await Quiz.findByIdAndDelete(id);
    res.status(200).json({ message: "Quiz deleted successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createQuiz,
  updateQuiz,
  deleteQuiz,
};