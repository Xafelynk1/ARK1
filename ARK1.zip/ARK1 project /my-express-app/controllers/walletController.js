const Wallet = require("../models/Wallet");

const viewBalance = async (req, res, next) => {
  try {
    const wallet = await Wallet.findOne({ userId: req.user.id });
    if (!wallet) {
      return res.status(404).json({ message: "Wallet not found" });
    }
    res.status(200).json({ balance: wallet.balance });
  } catch (error) {
    next(error);
  }
};

const fundWallet = async (req, res, next) => {
  try {
    const { amount } = req.body;
    const wallet = await Wallet.findOneAndUpdate(
      { userId: req.user.id },
      { $inc: { balance: amount } },
      { new: true }
    );
    res.status(200).json({ message: "Wallet funded successfully", wallet });
  } catch (error) {
    next(error);
  }
};

const withdrawFunds = async (req, res, next) => {
  try {
    const { amount } = req.body;
    const wallet = await Wallet.findOne({ userId: req.user.id });
    if (!wallet || wallet.balance < amount) {
      return res.status(400).json({ message: "Insufficient balance" });
    }
    wallet.balance -= amount;
    await wallet.save();
    res.status(200).json({ message: "Funds withdrawn successfully", wallet });
  } catch (error) {
    next(error);
  }
};

const purchaseEbook = async (req, res, next) => {
  try {
    const { ebookId, price } = req.body;
    const wallet = await Wallet.findOne({ userId: req.user.id });
    if (!wallet || wallet.balance < price) {
      return res.status(400).json({ message: "Insufficient balance" });
    }
    wallet.balance -= price;
    await wallet.save();
    res.status(200).json({ message: "Ebook purchased successfully", wallet });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  viewBalance,
  fundWallet,
  withdrawFunds,
  purchaseEbook,
};