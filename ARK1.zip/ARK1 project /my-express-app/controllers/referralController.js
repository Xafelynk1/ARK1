const Referral = require("../models/Referral");

const getReferrals = async (req, res, next) => {
  try {
    const referrals = await Referral.find({ referredBy: req.user.id });
    res.status(200).json(referrals);
  } catch (error) {
    next(error);
  }
};

const rewardReferral = async (req, res, next) => {
  try {
    const { referralId, reward } = req.body;
    const referral = await Referral.findById(referralId);
    if (!referral) {
      return res.status(404).json({ message: "Referral not found" });
    }
    referral.reward += reward;
    await referral.save();
    res.status(200).json({ message: "Referral rewarded successfully", referral });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getReferrals,
  rewardReferral,
};