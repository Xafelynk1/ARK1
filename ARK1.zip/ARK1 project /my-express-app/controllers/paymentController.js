const axios = require("axios");

const initiatePayment = async (req, res, next) => {
  try {
    const { email, amount, callbackUrl } = req.body;

    const response = await axios.post(
      "https://api.paystack.co/transaction/initialize",
      {
        email,
        amount: amount * 100, // Convert to kobo for Paystack
        callback_url: callbackUrl,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        },
      }
    );

    res.status(200).json({ message: "Payment initiated successfully", data: response.data });
  } catch (error) {
    next(error);
  }
};

const verifyPayment = async (req, res, next) => {
  try {
    const { transactionId } = req.params;

    const response = await axios.get(`https://api.paystack.co/transaction/verify/${transactionId}`, {
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
      },
    });

    if (response.data.status === "success") {
      res.status(200).json({ message: "Payment verified successfully", data: response.data });
    } else {
      res.status(400).json({ message: "Payment verification failed", data: response.data });
    }
  } catch (error) {
    next(error);
  }
};

module.exports = {
  initiatePayment,
  verifyPayment,
};