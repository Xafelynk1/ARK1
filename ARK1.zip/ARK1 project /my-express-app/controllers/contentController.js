const Content = require("../models/Content");

const uploadContent = async (req, res, next) => {
  try {
    const { title, type, file } = req.body;
    const content = await Content.create({ title, type, file });
    res.status(201).json({ message: "Content uploaded successfully", content });
  } catch (error) {
    next(error);
  }
};

const updateContent = async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const content = await Content.findByIdAndUpdate(id, updates, { new: true });
    res.status(200).json({ message: "Content updated successfully", content });
  } catch (error) {
    next(error);
  }
};

const deleteContent = async (req, res, next) => {
  try {
    const { id } = req.params;
    await Content.findByIdAndDelete(id);
    res.status(200).json({ message: "Content deleted successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  uploadContent,
  updateContent,
  deleteContent,
};