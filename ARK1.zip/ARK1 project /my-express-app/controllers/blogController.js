const Blog = require("../models/Blog");

const createBlog = async (req, res, next) => {
  try {
    const { title, content, imageUrl } = req.body;
    const blog = await Blog.create({ title, content, imageUrl });
    res.status(201).json({ message: "Blog created successfully", blog });
  } catch (error) {
    next(error);
  }
};

const updateBlog = async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const blog = await Blog.findByIdAndUpdate(id, updates, { new: true });
    res.status(200).json({ message: "Blog updated successfully", blog });
  } catch (error) {
    next(error);
  }
};

const deleteBlog = async (req, res, next) => {
  try {
    const { id } = req.params;
    await Blog.findByIdAndDelete(id);
    res.status(200).json({ message: "Blog deleted successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createBlog,
  updateBlog,
  deleteBlog,
};