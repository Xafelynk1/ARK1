const Admin = require("../models/Admin");
const User = require("../models/User");
const Content = require("../models/Content");

const adminLogin = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });
    if (!admin || admin.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    res.status(200).json({ message: "Admin logged in successfully", admin });
  } catch (error) {
    next(error);
  }
};

const viewAllUsers = async (req, res, next) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

const approveUserRequest = async (req, res, next) => {
  try {
    const { userId } = req.body;
    const user = await User.findByIdAndUpdate(userId, { status: "Approved" }, { new: true });
    res.status(200).json({ message: "User request approved", user });
  } catch (error) {
    next(error);
  }
};

const rejectUserRequest = async (req, res, next) => {
  try {
    const { userId } = req.body;
    const user = await User.findByIdAndUpdate(userId, { status: "Rejected" }, { new: true });
    res.status(200).json({ message: "User request rejected", user });
  } catch (error) {
    next(error);
  }
};

const manageContent = async (req, res, next) => {
  try {
    const { action, contentId, updates } = req.body;
    let result;
    if (action === "delete") {
      result = await Content.findByIdAndDelete(contentId);
    } else if (action === "update") {
      result = await Content.findByIdAndUpdate(contentId, updates, { new: true });
    }
    res.status(200).json({ message: `Content ${action}d successfully`, result });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  adminLogin,
  viewAllUsers,
  approveUserRequest,
  rejectUserRequest,
  manageContent,
};