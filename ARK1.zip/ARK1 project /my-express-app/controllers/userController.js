const User = require("../models/User");
const Quiz = require("../models/Quiz");

const signUp = async (req, res, next) => {
  try {
    const { username, email, password } = req.body;
    const user = await User.create({ username, email, password });
    res.status(201).json({ message: "User registered successfully", user });
  } catch (error) {
    next(error);
  }
};

const signIn = async (req, res, next) => {
  // Similar logic as in the original code
};

const viewPurchases = async (req, res, next) => {
  // Similar logic as in the original code
};

const participateQuiz = async (req, res, next) => {
  // Similar logic as in the original code
};

module.exports = {
  signUp,
  signIn,
  viewPurchases,
  participateQuiz,
};