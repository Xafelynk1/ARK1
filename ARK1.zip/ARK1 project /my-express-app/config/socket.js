const socketIo = require("socket.io");
const { chatHandler } = require("../utils/chatHandler");

const setupSocket = (server) => {
  const io = socketIo(server);

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);
    chatHandler(socket, io);
    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });
};

module.exports = { setupSocket };