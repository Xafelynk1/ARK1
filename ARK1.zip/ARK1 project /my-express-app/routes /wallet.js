const express = require("express");
const {
  viewBalance,
  fundWallet,
  withdrawFunds,
  purchaseEbook,
} = require("../controllers/walletController");

const router = express.Router();

router.get("/balance", viewBalance);
router.post("/fund", fundWallet);
router.post("/withdraw", withdrawFunds);
router.post("/purchase", purchaseEbook);

module.exports = router;