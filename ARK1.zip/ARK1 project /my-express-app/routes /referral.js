const express = require("express");
const { getReferrals, rewardReferral } = require("../controllers/referralController");

const router = express.Router();

router.get("/list", getReferrals);
router.post("/reward", rewardReferral);

module.exports = router;