const express = require("express");
const {
  signUp,
  signIn,
  viewPurchases,
  participateQuiz,
} = require("../controllers/userController");

const router = express.Router();

router.post("/signup", signUp);
router.post("/signin", signIn);
router.get("/purchases", viewPurchases);
router.put("/quiz/:id/participate", participateQuiz);

module.exports = router;