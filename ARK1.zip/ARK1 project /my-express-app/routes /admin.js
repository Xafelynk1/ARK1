const Ebook = require("../models/Ebook");
const Quiz = require("../models/Quiz");
const User = require("../models/User");

const uploadEbook = async (req, res, next) => {
  try {
    const { title, price, description, fileUrl, posterUrl } = req.body;
    const ebook = await Ebook.create({ title, price, description, fileUrl, posterUrl });
    res.status(201).json({ message: "Ebook uploaded successfully", ebook });
  } catch (error) {
    next(error);
  }
};

const updateQuiz = async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const quiz = await Quiz.findByIdAndUpdate(id, updates, { new: true });
    res.status(200).json({ message: "Quiz updated successfully", quiz });
  } catch (error) {
    next(error);
  }
};

const manageUsers = async (req, res, next) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

const deleteContent = async (req, res, next) => {
  try {
    const { id } = req.params;
    await Ebook.findByIdAndDelete(id);
    await Quiz.findByIdAndDelete(id);
    res.status(200).json({ message: "Content deleted successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  uploadEbook,
  updateQuiz,
  manageUsers,
  deleteContent,
};