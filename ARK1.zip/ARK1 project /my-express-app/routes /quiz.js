const express = require("express");
const { createQuiz, updateQuiz, deleteQuiz } = require("../controllers/quizController");

const router = express.Router();

router.post("/create", createQuiz);
router.put("/update/:id", updateQuiz);
router.delete("/delete/:id", deleteQuiz);

module.exports = router;