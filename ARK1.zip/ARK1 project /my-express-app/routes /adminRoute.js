const express = require("express");
const { toggleQuizRoom, updateParticipants, grantSpecialRules } = require("../controllers/adminController");

const router = express.Router();

router.put("/quiz/:id/toggle", toggleQuizRoom);
router.put("/quiz/:id/participants", updateParticipants);
router.put("/user/:id/special-rules", grantSpecialRules);

module.exports = router;