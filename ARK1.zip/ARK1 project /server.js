const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const dotenv = require("dotenv");
const mongoose = require("mongoose");

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

// Middleware
app.use(express.json());
app.use((req, res, next) => {
  req.io = io; // Attach io instance to req for use in controllers
  next();
});

// Database connection
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch((error) => console.log("MongoDB connection error:", error));

// Routes
const liveChatRoutes = require("./routes/liveChat");
const walletRoutes = require("./routes/wallet");
const postersRoutes = require("./routes/posters");
const purchaseRoutes = require("./routes/purchase");

app.use("/api/livechat", liveChatRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/posters", postersRoutes);
app.use("/api/purchase", purchaseRoutes);

// WebSocket handlers
const handleChatSocket = require("./sockets/chatSocket");
handleChatSocket(io);

// Wallet memory (store balance for simplicity)
let wallet = {
  balance: 0,
};

let liveFeed = [
  { title: "Live Feed 1", description: "This is the first feed.", time: "10:00 AM" },
  { title: "Live Feed 2", description: "This is the second feed.", time: "10:30 AM" },
];

let posters = [
  { id: 1, title: "eBook 1", image: "/images/ebook1.jpg", price: 1500.0 },
  { id: 2, title: "eBook 2", image: "/images/ebook2.jpg", price: 2000.0 },
];

// Fetch wallet balance
app.get("/api/wallet/balance", (req, res) => {
  res.json({ balance: wallet.balance });
});

// Fund wallet
app.post("/api/wallet/fund", (req, res) => {
  const { amount } = req.body;
  if (amount <= 0) return res.status(400).json({ message: "Invalid amount" });
  wallet.balance += parseFloat(amount);
  res.json({ success: true, balance: wallet.balance });
});

// Withdraw funds
app.post("/api/wallet/withdraw", (req, res) => {
  const { amount } = req.body;
  if (amount <= 0 || amount > wallet.balance) {
    return res.status(400).json({ message: "Invalid or insufficient funds" });
  }
  wallet.balance -= parseFloat(amount);
  res.json({ success: true, balance: wallet.balance });
});

// Get live feed
app.get("/api/live-feed", (req, res) => {
  res.json(liveFeed);
});

// Get posters (eBooks)
app.get("/api/posters", (req, res) => {
  res.json(posters);
});

// Handle purchase (dummy logic)
app.post("/api/purchase", (req, res) => {
  const { posterId } = req.body;
  const poster = posters.find(p => p.id === parseInt(posterId));

  if (!poster) {
    return res.status(404).json({ message: "Poster not found" });
  }

  if (wallet.balance >= poster.price) {
    wallet.balance -= poster.price;
    res.json({ success: true, message: "Purchase successful!" });
  } else {
    res.status(400).json({ message: "Insufficient funds for purchase" });
  }
});

// WebSocket chat functionality
const handleChatSocket = require("./sockets/chatSocket");
handleChatSocket(io);

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));